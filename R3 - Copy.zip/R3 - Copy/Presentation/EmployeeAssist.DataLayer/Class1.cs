﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeAssist.DataLayer
{
    public class Class1
    {
    }
}
