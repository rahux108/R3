﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EmployeeAssist.Models;

namespace EmployeeAssist.Controllers
{
    public class ReaderController : Controller
    {
        // GET: Search
        public ActionResult Index()
        {
            return View(new ReaderViewModel()
            {

                CountryOptions = new List<ListItem>()
                {
                    new ListItem {id="",value="" },
                    new ListItem { id="UnitedStates", value="UnitedStates" },
                     new ListItem { id="NewZealand", value="NewZealand" }
                },
                StateOptions = new List<ListItem>(),
                CityOptions = new List<ListItem>(),
                CategoryOptions = new List<ListItem>()
                {
                    new ListItem {id="",value="" },
                    new ListItem { id="Accomodation",value="Accomodation"},
                    new ListItem { id="Allowances",value="Allowances"}
                },
                SubCategoryOptions = new List<ListItem>()
            });
        }

        [HttpPost]
        public ActionResult Index(ReaderViewModel model)
        {
            return View(model);
        }


        // GET: CreateInformation
        public ActionResult CreateInformation()
        {

            var informtionViewModel = new InformationViewModel
            {
                CountryOptions = new List<ListItem>()
                {
                    new ListItem {id="",value="" },
                    new ListItem { id="UnitedStates", value="UnitedStates" },
                     new ListItem { id="NewZealand", value="NewZealand" }   
                },
                StateOptions = new List<ListItem>(),
                CityOptions = new List<ListItem>(),
                CategoryOptions = new List<ListItem>()
                {
                    new ListItem {id="",value="" },
                    new ListItem { id="Accomodation",value="Accomodation"},
                    new ListItem { id="Allowances",value="Allowances"}
                },
                SubCategoryOptions = new List<ListItem>()                
            };

            return View(informtionViewModel);
        }

        [HttpPost]
        public ActionResult CreateInformation(InformationViewModel model)
        {
            //Call DAL to insert information

            return View(model);
        }


        // GET: Information
        public ActionResult ShowInformation()
        {
            var informtionViewModel = new InformationViewModel
            {
                CountryOptions = new List<ListItem>()
                {
                    new ListItem {id="",value="" },
                    new ListItem { id="UnitedStates", value="UnitedStates" },
                     new ListItem { id="NewZealand", value="NewZealand" }   
                },
                StateOptions = new List<ListItem>(),
                CityOptions = new List<ListItem>(),
                CategoryOptions = new List<ListItem>()
                {
                    new ListItem {id="",value="" },
                    new ListItem { id="Accomodation",value="Accomodation"},
                    new ListItem { id="Allowances",value="Allowances"}
                },
                SubCategoryOptions = new List<ListItem>(),

                information = new List<Information>() { 
                new Information{
                    Likes=10,
                Descrption="IRS Taxpayer Assistance Centers (TACs) are your source for personal tax help when you believe your tax issue can only be handled face-to-face. Keep in mind, many questions can be resolved online without waiting in line. Through IRS.gov you can. "
                +"If you have a tax account issues and feel that it requires talking with someone face-to-face, visit your local TAC or request an appointment at those TACs that provide face-to-face assistance by appointment.",
                Url="http://google.com",
                image=new MongoPictureModel{ FileName= @"~/Content/Image/IRS_building_2145.jpg"}},

                new Information{
                    Likes=5,
                Descrption="MyTestPage",
                Url="http://google.com",
                image=new MongoPictureModel{ FileName=@"~/Content/Image/irs_building_sign.jpg"}}

                }
            };
            return View(informtionViewModel);
        }


        [HttpGet]
        public JsonResult GetStates(string country)
        {
            var result = new JsonResult();
            result.JsonRequestBehavior = JsonRequestBehavior.AllowGet;
            //mock

            result.Data = new List<ListItem>()
            {
                new ListItem {id="",value="" },
               new ListItem { id="Florida",value="Florida"},
               new ListItem { id= "Georgia",value="Georgia" },
               new ListItem { id = "North Carolina", value= "North Carolina" },
            };
            return result;
        }

        [HttpGet]
        public JsonResult GetCities(string country, string state)
        {
            var result = new JsonResult();
            result.JsonRequestBehavior = JsonRequestBehavior.AllowGet;
            //mock
            if (state.Equals("Florida", StringComparison.InvariantCultureIgnoreCase))
            {
                result.Data = new List<ListItem>()
                {
                    new ListItem {id="",value="" },
                   new ListItem { id="St Pete",value="St Pete"},
                   new ListItem { id= "JacksonVille",value="JacksonVille" },
                };
            }
            if (state.Equals("Georgia", StringComparison.InvariantCultureIgnoreCase))
            {
                result.Data = new List<ListItem>()
                {
                    new ListItem {id="",value="" },
                   new ListItem { id="Atlanta",value="Atlanta"},
                   new ListItem { id= "Alpharetta",value="Alpharetta" },
                };
            }
            if (state.Equals("North Carolina", StringComparison.InvariantCultureIgnoreCase))
            {
                result.Data = new List<ListItem>()
                {
                    new ListItem {id="",value="" },
                   new ListItem { id="Charlotte",value="Charlotte"},
                };
            }
            return result;

        }

        [HttpGet]
        public JsonResult GetCategories(string country, string city, string state)
        {
            var result = new JsonResult();
            result.JsonRequestBehavior = JsonRequestBehavior.AllowGet;
            //mock
            result.Data = new List<ListItem>()
                {
                new ListItem {id="",value="" },
                   new ListItem { id="Accomodation",value="Accomodation"},
                   new ListItem { id="Allowances",value="Allowances"},
                };
            return result;
        }


        [HttpGet]
        public JsonResult GetSubCategories(string country, string city, string state, string category)
        {
            var result = new JsonResult();
            result.JsonRequestBehavior = JsonRequestBehavior.AllowGet;
            //mock
            if (category.Equals("Accomodation", StringComparison.InvariantCultureIgnoreCase))
            {
                result.Data = new List<ListItem>()
                {
                    new ListItem {id="",value="" },
                   new ListItem { id="Share",value="Share"},
                   new ListItem { id="New",value="New"},
                };
            }
            if (category.Equals("Allowances", StringComparison.InvariantCultureIgnoreCase))
            {
                result.Data = new List<ListItem>()
                {
                    new ListItem {id="",value="" },
                   new ListItem { id="ChildEducation",value="ChildEducation"},
                   new ListItem { id="Internet",value="Internet"},
                };
            }

            return result;
        }



    }
}