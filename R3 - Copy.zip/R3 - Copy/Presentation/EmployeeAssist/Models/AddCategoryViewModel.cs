﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeAssist.Models
{
    public class AddCategoryViewModel
    {
        public string Category { get; set; }

        public string SubCategory { get; set; }
    }
}