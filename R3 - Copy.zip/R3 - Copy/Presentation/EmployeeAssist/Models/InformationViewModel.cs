﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeAssist.Models
{
    public class InformationViewModel : ReaderViewModel
    {
        public List<Information> information { get; set; }
    }

    public class Information
    {
        public int Likes { get; set; }
        public string Descrption { get; set; }
        public string Url { get; set; }
        public MongoPictureModel image { get; set; }
        public MongoVideoModel video { get; set; }
    }

    public class MongoPictureModel
    {
        public string FileName { get; set; }
        public string PictureDataAsString { get; set; }
    }

    public class MongoVideoModel
    {
        public string FileName { get; set; }
        public string VideoDataAsString { get; set; }
    }
}